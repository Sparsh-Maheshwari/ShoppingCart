import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { FrontPageComponent } from './front-page/front-page.component';
import { AllCategoriesComponent } from './all-categories/all-categories.component';
import { BreadComponent } from './bread/bread.component';
import { DairyComponent } from './dairy/dairy.component';
import { FruitsComponent } from './fruits/fruits.component';
import { VegetablesComponent } from './vegetables/vegetables.component';
import { ClothingComponent } from './clothing/clothing.component';
import { CartComponent } from './cart/cart.component';
import { CheckOutComponent } from './check-out/check-out.component';
import { ThankYouComponent } from './thank-you/thank-you.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    FrontPageComponent,
    AllCategoriesComponent,
    BreadComponent,
    DairyComponent,
    FruitsComponent,
    VegetablesComponent,
    ClothingComponent,
    CartComponent,
    CheckOutComponent,
    ThankYouComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
