import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dairy',
  templateUrl: './dairy.component.html',
  styleUrls: ['./dairy.component.css']
})
export class DairyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
