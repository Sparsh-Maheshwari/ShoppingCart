import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AllCategoriesComponent } from './all-categories/all-categories.component';
import { FrontPageComponent } from './front-page/front-page.component';
import { BreadComponent } from './bread/bread.component';
import { DairyComponent } from './dairy/dairy.component';
import { FruitsComponent } from './fruits/fruits.component';
import { VegetablesComponent } from './vegetables/vegetables.component';
import { ClothingComponent } from './clothing/clothing.component';
import { CartComponent } from './cart/cart.component';
import { CheckOutComponent } from './check-out/check-out.component';
import { ThankYouComponent } from './thank-you/thank-you.component';


const routes: Routes = [
  {path: '', component: FrontPageComponent},
  {path: 'all-categories', component : AllCategoriesComponent},
  {path: 'bread', component : BreadComponent},
  {path: 'dairy', component : DairyComponent},
  {path: 'fruits', component: FruitsComponent},
  {path: 'vegetables', component: VegetablesComponent},
  {path: 'clothing', component: ClothingComponent},
  {path: 'cart', component: CartComponent},
  {path: 'cart/:id', component : CartComponent},
  {path: 'check-out', component: CheckOutComponent},
  {path: 'thank-you', component: ThankYouComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
